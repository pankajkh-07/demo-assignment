/**
 * Retrieves the translation of text.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/packages/packages-i18n/
 */
import { __ } from '@wordpress/i18n';

/**
 * React hook that is used to mark the block wrapper element.
 * It provides all the necessary props like the class name.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/packages/packages-block-editor/#useblockprops
 */
import { useBlockProps } from '@wordpress/block-editor';

/**
 * Lets webpack process CSS, SASS or SCSS files referenced in JavaScript files.
 * Those files can contain any CSS code that gets applied to the editor.
 *
 * @see https://www.npmjs.com/package/@wordpress/scripts#using-css
 */
import './editor.scss';
import { useState, useEffect } from 'react';
import { SelectControl, PanelBody, TextControl, Spinner,ComboboxControl } from '@wordpress/components';
import { InspectorControls } from '@wordpress/block-editor';
import penguine_image from './logo.svg';
// import apiFetch from '@wordpress/api-fetch';

/**
 * The edit function describes the structure of your block in the context of the
 * editor. This represents what the editor will render when the block is used.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/block-api/block-edit-save/#edit
 *
 * @return {Element} Element to render.
 */
const API_KEY = '7fqge2qgxcdrwqbcgeywwdj2';
const GENRES_ENDPOINT = 'https://api.penguinrandomhouse.com/resources/v2/title/domains/PRH.UK/categories';
const BOOKS_ENDPOINT = 'https://api.penguinrandomhouse.com/resources/v2/title/domains/PRH.UK/works/views/uk-list-display';
 
const Edit = ({ attributes, setAttributes }) => {
	 const { genre, title } = attributes;
	 const [genres, setGenres] = useState([]);
	 const [books, setBooks] = useState([]);
	 const [loading, setLoading] = useState(false);

	 useEffect(() => {
		 fetch(`${GENRES_ENDPOINT}?rows=15&catSetId=PW&api_key=${API_KEY}`)
			 .then(res => res.json())
			 .then(data => {
				 setGenres(data.data.categories || []);
			 })
			 .catch(error => console.error('Error fetching genres:', error));
	 }, []);

	 useEffect(() => {
		 if (genre) {
			 setLoading(true);
			 fetch(`${BOOKS_ENDPOINT}?rows=1&catUri=${genre}&catSetId=PW&sort=weeklySales&dir=desc&api_key=${API_KEY}`)
				 .then(res => res.json())
				 .then(data => {
					 setBooks(data.data.works || []);
					 setLoading(false);
				 })
				 .catch(error => {
					 console.error('Error fetching books:', error);
					 setLoading(false);
				 });
		 }
	 }, [genre]);

	 return (
		 <>
			 <InspectorControls>
				 <PanelBody title="Settings">
					 <TextControl 
						 label="Block Title" 
						 value={title} 
						 onChange={(value) => setAttributes({ title: value })} 
					 />
					 <SelectControl 
						 label="Select Genre"
						 value={genre}
						 options={[{ label: 'Select a genre', value: '' }, ...genres.map(g => ({ label: g.description || 'Unknown', value: g.catUri || '' }))]}
						 onChange={(value) => setAttributes({ genre: value })} 
					 />
				 </PanelBody>
			 </InspectorControls>
			 <div {...useBlockProps()}>
				{
					!genre &&
					<ComboboxControl
						label="Choose Genre"
						options={[{ label: 'Select a genre', value: '' }, ...genres.map(g => ({ label: g.description || 'Unknown', value: g.catUri || '' }))]}
						value={genre}
						onChange={(value) => setAttributes({ genre: value })} 
						allowReset
					/>
				}
				 
				 {loading ? <Spinner /> : books.length > 0 ? (
					<div className='book_container'>
						<h2 className='book_heading'>{title || "Bestsellers"}</h2>
						<div className="book">
							<a href={`https://www.penguin.co.uk/${books[0].seoFriendlyUrl}`} target="_blank">
								<img src={books[0].coverUrls.large.coverUrl} alt={books[0].title} />
							</a>
							<a href={`https://www.penguin.co.uk/${books[0].seoFriendlyUrl}`} target="_blank">
								<h3 className='book_title'>{books[0].title}</h3>
							</a>
							<p className='book_author_name'>{books[0].authors.slice(0, 2).map(author => author.authorDisplay).join(', ')}</p>
							<a className="book_buy_now" href={books[0].affiliateLinks.find(link => link.affiliateType === 'amazon')?.url} target="_blank" rel="noopener noreferrer">Buy From Amazon</a>
							<div className="book_deco">
								<a href={`https://www.penguin.co.uk/${books[0].seoFriendlyUrl}`} target="_blank"><img src={penguine_image} alt="Penguin Logo" className="book_deco_image" /></a>							
							</div>
						</div>
					 </div>
				 ) : <p>No books available. Try selecting the genre first.</p>}
			 </div>
		 </>
	 );
 };

 export default Edit;
 