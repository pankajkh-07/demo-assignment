const { useBlockProps } = wp.blockEditor;
//const { useDispatch } = wp.data;

const save = (props) => {
    console.log(props);
    const blockProps = useBlockProps.save();
    const { attributes } = props;
    console.log("attributes",attributes);
    /*const { editPost } = useDispatch('core/editor'); */
    return (
        <div
            className="biblio-bestseller-block"
				data-genre={attributes.genre}
				data-title={attributes.title}
            {...blockProps}
        >
            <h2>{attributes.title}</h2>
            <p>{attributes.genre}</p>
        </div>
    );
};

export default save;

